// Main package for the application
package com.foodordering.system;

/**
 * Command interface.
 */
interface Command {
    void execute();
}
